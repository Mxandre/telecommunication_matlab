%%
clear all
clc;
%% 基本参数设置
CodeNum = 10;                           % 二进制码数
BinaryCode = randi([0,1],1,CodeNum);    % 一行CodeNum列的，0或1的基带信号
SampleNum = 100;                        % 每个码元的采样数
Tb = 0.001;                             % 码长
fm = 1/Tb;                              % 基带信号带宽
Tp = CodeNum * Tb;                      % 观测时间
T = Tb / SampleNum;                     % 采样间隔
fs = 1/T;                               % 采样频率
N = CodeNum * SampleNum;                % 采样点数
t = 0 : T : Tp-T;                       % 时域采样范围
F = 1/Tp;                               % 频谱分辨率
fM = F * N;                             % 频域观测极限
f = 0 : F : fM-F;                       % 频域观测范围
fc = 10000;                             % 载波频率
K = 0.8;                                % 信道传输系数（认为信号只受固定衰减，不失真）
%% 生成基带信号
an = BinaryCode(ones(1,SampleNum), :);  % 对每个码元采样SampleNum次，得到基带信号，但此时是矩阵
an = reshape(an,1,N);                   % 将矩阵变为行向量 得到基带信号
%% 2ASK调制
carrier = cos(2*pi*fc*t);               % 生成载波
ask = an .* carrier;% 生成ASK
figure(1);
subplot(3,1,1);plot(t*1000,ask);        % 绘制ASK时域图像
grid on;
xlabel("t/ms");ylabel("2ASK调制信号");
title("2ASK时域波形");
ask_f = fft(ask)/N;                      % ASK信号的频谱
mag = 2*abs(ask_f(1:N/2+1));             % 信号的单边幅度谱
subplot(3,1,2);plot(f(1:N/2+1),mag);     % 双边谱变单边，画一半。绘制ASK的频域波形
grid on; 
xlabel("f/Hz");ylabel("F(jw)");
title("2ASK频域波形");
%% 传输过程
ask = K*ask;                                        % 乘性干扰
ask = awgn(ask,20);                                 % 加入高斯白噪声 信噪比为20dB（大信噪比）
subplot(3,1,3);                                     % 绘制接收机输入端的信号时域波形
plot(t*1000,ask);
title("接收机输入端的信号");
xlabel("t/ms");ylabel("2ASK");
hold on;
%% 2ASK解调

% 带通滤波器参数
fn = fs;                                            % 滤波器采样速率
fp = [fc-fm fc+fm];                                 % 通带
fb = [fc-2*fm fc+2*fm];                             % 阻带
Rp = 3;                                             % 期望通带边界处降至-3dB
Rs = 30;                                            % 期望阻带边界处降至-30dB
Wp = 2*fp / fn;                                     % 归一化频率
Wb = 2*fb / fn;
[n,Wn] = buttord(Wp,Wb,Rp,Rs);                      % 计算滤波器阶数及截止频率
[b,a] = butter(n,Wn);                               % 计算传递函数的表达式
[H, F] = freqz(b,a,N/2+1, fn);                      % 计算滤波器的幅频响应，因为是单边谱，所以计算点数除2
figure(2);subplot(3,1,1);                           % 绘制带通滤波器的幅频特性
plot(F,20*log10(abs(H)));                 
grid on;
axis([0 f(N/2) -30 3]);
title("带通滤波器的幅频特性");
xlabel("f/(Hz)");ylabel("幅频特性(dB)");

ask_f = fft(ask);                                   % 接收机输入端ASK信号的频谱
mag = 2*abs(ask_f(1:N/2+1))/N;                      % 接收机输入端ASK信号的频谱幅度
figure(2);hold on;subplot(3,1,2);plot(f(1:N/2+1),mag);      % 双边谱变单边，画一半
grid on; 
xlabel("f/Hz");ylabel("F(jw)");

ask_cfA = mag(1:N/2+1) .* (abs(H)');                % 通过带通滤波器后的频谱幅度
subplot(3,1,3);                                     % 绘制该频谱
plot(f(1:N/2+1),ask_cfA);
xlabel("f/Hz");ylabel("F(jw)");
grid on;
hold on;
for i = 1 : N - (N/2 + 1)
    ask_cfA(N/2 + 1 + i) = ask_cfA(N/2 - i + 1);    % 拓展回双边谱，满足矩阵乘法要求
end
ask_cf = ask_cfA .* exp(1j*angle(ask_f));           % 幅度谱换回频谱，忽略滤波器的时延
ask = real(ifft(ask_cf))*N/2;
ask = ask.*carrier;                                 % 相干解调
figure(3);subplot(3,1,1)                            % 绘制乘本地载波后的波形
plot(t*1000,ask);
xlabel("t/ms");ylabel("2ASK");
grid on;
% 低通滤波器参数
fn = fs;
fp = fm;                                            % 通带
fb = 2*fm;                                          % 阻带
Rp = 3; 
Rs = 30;
Wp = 2*fp / fn;                                     % 归一化频率
Wb = 2*fb / fn;
[n,Wn] = buttord(Wp,Wb,Rp,Rs);
[b,a] = butter(n,Wn); 
[H, F] = freqz(b,a,N/2+1, fn);                      % 因为是单边谱，所以除2

ask_f = fft(ask)/N;
ask_fA = 2 * abs(ask_f(1:N/2+1)) .* abs(H)';        % 通过低通滤波器后的频谱幅度
subplot(3,1,2);
plot(f(1:N/2+1),ask_fA);
xlabel("f/Hz");ylabel("F(jw)");
grid on;
for i = 1 : N - (N/2+1)
    ask_fA(N/2+1+i) = ask_fA(N/2+1-i);
end

ask_f = ask_fA .* exp(1j * angle(ask_f));           % 把幅度谱换回频谱
b = real(ifft(ask_f)*N/2);                          % 逆变换得到时域波形
subplot(3,1,3);
plot(t,b);
xlabel("t/ms");ylabel("2ASK");
grid on;
hold on;
%抽样判决
k = 0.33;                                           % 判决门限
res = zeros(1,N + N/20);                            % 判决结果
for i = 50 : 100 : 950
    res(1,i:i+100) = b(1,i) >= k ;
end
figure(4);                                        % 绘制判决结果
plot(t, res(50 : end-1));            
xlabel("t/ms");ylabel("res(t)");
grid on;
hold on;
figure(5); hold on;                                         % 绘制传输数据
plot(t,an);title("传输数据");
xlabel("t/ms");ylabel("an(t)");
grid on;
hold on;