%%
clear all;
clc;
%% 基本参数设置
CodeNum = 10;                                   % 二进制码数
O_BinaryCode = randi([0,1],1,CodeNum);          % 欲传输的数据
BinaryCode =  (~O_BinaryCode) + 0;              % +0 转为double类型
SampleNum = 100;                                % 每个码元的采样数
Tb = 0.001;                                     % 码长
fm = 1/Tb;                                      % 基带信号带宽
Tp = CodeNum * Tb;                              % 观测时间 0.01
T = Tb / SampleNum;                             % 采样间隔 1e-4
fs = 1/T;                                       % 采样频率 10k
N = CodeNum * SampleNum;                        % 采样点数
t = 0 : T : Tp-T;                               % 时域采样范围
F = 1/Tp;                                       % 频谱分辨率
fM = F * N;                                     % 频域观测极限
f = 0 : F : fM-F;                               % 频域观测范围
fc1 = 10000;                                    % 载波1频率
fc2 = 25000;                                    % 载波2频率
%% 生成基带信号
an1 = O_BinaryCode(ones(1,SampleNum), :);       % 对每个码元采样SampleNum次，得到基带信号，但此时是矩阵 将第一行重复一百次
an2 = BinaryCode(ones(1,SampleNum), :);
an1 = reshape(an1,1,N);                         % 将矩阵变为行向量 得到基带信号
an2 = reshape(an2,1,N);
%% 2FSK调制
carrier1 = cos(2*pi*fc1*t);                     % 生成载波
carrier2 = cos(2*pi*fc2*t); 
fsk = an1 .* carrier1 + an2 .* carrier2;        % 生成2FSK
subplot(3,1,1);plot(t*1000,fsk);                % 绘制2FSK时域图像
grid on;
xlabel("t/ms");ylabel("2FSK调制信号");
title("2FSK时域波形");
fsk_f = fft(fsk)/N;                             % 基带信号的频谱
mag = 2*abs(fsk_f(1:N/2+1));                    % 基带信号的单边幅度谱
subplot(3,1,2);plot(f(1:N/2+1),mag);            % 双边谱变单边，画一半。绘制FSK的频域波形
grid on;
xlabel("f/Hz");ylabel("F(jw)");
axis([0 5e4 0 1]);
title("2FSK频域波形");
%% 传输过程
K = 0.8;                                            % 信道传输系数（认为信号只受固定衰减，不失真）
fsk = K*fsk;                                        % 乘性干扰
fsk = awgn(fsk,20);                                 % 加入高斯白噪声 信噪比为20dB（大信噪比）
subplot(3,1,3);                                     % 绘制接收机输入端的信号时域波形
plot(t*1000,fsk);
title("接收机输入端的信号");
xlabel("t/ms");ylabel("2FSK");
%% 2FSK解调

% 带通滤波器参数
fn = fs;                                            % 滤波器采样速率
fp = [fc1-fm fc1+fm];                               % 通带
fb = [fc1-2*fm fc1+2*fm];                           % 阻带
Rp = 3;                                             % 期望通带边界处降至-3dB
Rs = 30;                                            % 期望阻带边界处降至-30dB
Wp = 2*fp / fn;                                     % 归一化频率
Wb = 2*fb / fn;
[n,Wn] = buttord(Wp,Wb,Rp,Rs);                      % 计算滤波器阶数及截止频率
[b,a] = butter(n,Wn);                               % 计算传递函数的表达式
[H1, F] = freqz(b,a,N/2+1, fn);                     % 计算滤波器的幅频响应，因为是单边谱，所以计算点数除2
figure(2);subplot(5,1,1);                           % 绘制带通滤波器的幅频特性
plot(F,20*log10(abs(H1)));                 
grid on;
axis([0 f(N/2) -30 3]);
xlabel("f/(Hz)");ylabel("幅频特性(dB)");

% 带通滤波器参数
fn = fs;                                            % 滤波器采样速率
fp = [fc2-fm fc2+fm];                               % 通带
fb = [fc2-2*fm fc2+2*fm];                           % 阻带
Rp = 3;                                             % 期望通带边界处降至-3dB
Rs = 30;                                            % 期望阻带边界处降至-30dB
Wp = 2*fp / fn;                                     % 归一化频率
Wb = 2*fb / fn;
[n,Wn] = buttord(Wp,Wb,Rp,Rs);                      % 计算滤波器阶数及截止频率
[b,a] = butter(n,Wn);                               % 计算传递函数的表达式
[H2, F] = freqz(b,a,N/2+1, fn);                     % 计算滤波器的幅频响应，因为是单边谱，所以计算点数除2
figure(2);subplot(5,1,2);                           % 绘制带通滤波器的幅频特性
plot(F,20*log10(abs(H2)));                 
grid on;
axis([0 f(N/2) -30 3]);
title("带通滤波器的幅频特性");
xlabel("f/(Hz)");ylabel("幅频特性(dB)");


fsk_f = fft(fsk);                                   % 接收机输入端FSK信号的频谱
mag = 2*abs(fsk_f(1:N/2+1))/N;                      % 接收机输入端FSK信号的频谱幅度
figure(2);subplot(5,1,3);plot(f(1:N/2+1),mag);      % 双边谱变单边，画一半
grid on; 
xlabel("f/Hz");ylabel("F(jw)");

fsk_cfA1 = mag(1:N/2+1) .* (abs(H1)');              % 通过带通滤波器1后的频谱幅度
subplot(5,1,4);                                     % 绘制该频谱
plot(f(1:N/2+1),fsk_cfA1);
xlabel("f/Hz");ylabel("F(jw)");
grid on;

fsk_cfA2 = mag(1:N/2+1) .* (abs(H2)');              % 通过带通滤波器2后的频谱幅度
subplot(5,1,5);                                     % 绘制该频谱
plot(f(1:N/2+1),fsk_cfA2);
xlabel("f/Hz");ylabel("F(jw)");
grid on;

for i = 1 : N - (N/2 + 1)
    fsk_cfA1(N/2 + 1 + i) = fsk_cfA1(N/2 - i + 1);  % 拓展回双边谱，满足矩阵乘法要求
    fsk_cfA2(N/2 + 1 + i) = fsk_cfA2(N/2 - i + 1);
end
fsk_cf1 = fsk_cfA1 .* exp(1j*angle(fsk_f));         % 幅度谱换回频谱，忽略滤波器的时延
fsk_cf2 = fsk_cfA2 .* exp(1j*angle(fsk_f));
fsk1 = real(ifft(fsk_cf1))*N/2;
fsk2 = real(ifft(fsk_cf2))*N/2;
fsk1 = fsk1.*carrier1;                              % 相干解调
fsk2 = fsk2.*carrier2;
figure(3);subplot(2,2,1)                            % 绘制乘本地载波后的波形
plot(t*1000,fsk1);
xlabel("t/ms");ylabel("FSK1");
grid on;
figure(3);subplot(2,2,3)                            
plot(t*1000,fsk2);
xlabel("t/ms");ylabel("FSK2");
grid on;
% 低通滤波器参数
fn = fs;
fp = fm;                                            % 通带
fb = 2*fm;                                          % 阻带
Rp = 3; 
Rs = 30;
Wp = 2*fp / fn;                                     % 归一化频率
Wb = 2*fb / fn;
[n,Wn] = buttord(Wp,Wb,Rp,Rs);
[b,a] = butter(n,Wn); 
[H, F] = freqz(b,a,N/2+1, fn);                      % 因为是单边谱，所以除2

fsk_f1 = fft(fsk1)/N;
fsk_f2 = fft(fsk2)/N;
fsk_fA1 = 2 * abs(fsk_f1(1:N/2+1)) .* abs(H)';      % 通过低通滤波器后的频谱幅度
fsk_fA2 = 2 * abs(fsk_f2(1:N/2+1)) .* abs(H)';
% subplot(2,2,2);
% plot(f(1:N/2+1),fsk_fA1);
% xlabel("f/Hz");ylabel("F(jw)");
% grid on;
% subplot(2,2,4);
% plot(f(1:N/2+1),fsk_fA2);
% xlabel("f/Hz");ylabel("F(jw)");
% grid on;
for i = 1 : N - (N/2+1)
    fsk_fA1(N/2+1+i) = fsk_fA1(N/2+1-i);
    fsk_fA2(N/2+1+i) = fsk_fA2(N/2+1-i);
end

fsk_f1 = fsk_fA1 .* exp(1j * angle(fsk_f1));        % 把幅度谱换回频谱
fsk_f2 = fsk_fA2 .* exp(1j * angle(fsk_f2));
b1 = real(ifft(fsk_f1)*N/2);                        % 逆变换得到时域波形
b2 = real(ifft(fsk_f2)*N/2);
subplot(2,2,2);plot(t,b1);
xlabel("t/ms");ylabel("FSK1");
grid on;
subplot(2,2,4);plot(t,b2);
xlabel("t/ms");ylabel("FSK2");
grid on;
%抽样判决
res = zeros(1,N + N/20);                            % 判决结果
for i = 50 : 100 : 950
    res(1,i:i+100) = b1(1,i) > b2(1,i) ;
end
figure(4);                                          % 绘制判决结果
plot(t, res(50 : end-1),'Color','r');            
xlabel("t/ms");ylabel("res(t)");
grid on;
figure(5);                                          % 绘制传输数据
plot(t,an1);title("传输数据");
xlabel("t/ms");ylabel("an(t)");
grid on;