close all
clc;
clear;
%%
CodeNum = 10;   %二进制码元数
BinaryCode = randi([0,1], 1, CodeNum);   %随机二进制码元
SampleNum = 100;    %每个码元采样数目
Tb = 0.001;  %码长
fm = 1/Tb;  %基带信号带宽
Tp = Tb*CodeNum;    %观测时间
T = Tb / SampleNum;     %采样间隔
fs = 1/T;   %采样间隔
N = CodeNum * SampleNum;    %采样点数
t = 0 : T : Tp-T;     %时域采样范围
F = 1/Tp;   %频谱分辨率
fM = F * N;     %最所需观测范围
f = 0 : F : fM - F;     %频域观测范围
fc = 10000;     %载波频率
%%
%生成基带信号
an = BinaryCode(ones(1,SampleNum), :);  %将BinaryCode转化为矩阵
an = reshape(an, [1, N]);   %将信号全部转换为行向量
figure(1);                  % 绘制第1幅图
subplot(2, 1, 1);               % 窗口分割成2*1的，当前是第1个子图
plot(t,an,'LineWidth',2);% 绘制基带码元波形，线宽为2
title('基带信号波形');      % 标题
xlabel('时间/s');           % x轴标签
ylabel('幅度');             % y轴标签
axis([0,Tp, 0, 1])   % 坐标范围限制
%%
%将单极性信号转换为双极性
for n = 1 : length(an)
    if an(n) == 1
        an(n) = -1;
    else
        an(n) = 1;
    end
end
%%
%2psk调制
carrier = cos(2*pi*fc*t);   %载波
psk = an .* carrier;    %2psk模拟调制

subplot(2, 1, 2)                % 窗口分割成2*1的，当前是第2个子图
plot(t,psk);  % 绘制PASK的波形
title('2PSK信号波形')   % 标题
axis([0,Tp,-1.1,1.1]);  % 坐标范围限制
xlabel('时间/s');           % x轴标签
ylabel('幅度');             % y轴标签

%%
%添加高斯白噪声
tz = awgn(psk, 15);     %添加高斯白噪声，SNR=15
figure(2);                  % 绘制第2幅图
subplot(2, 1, 1);               % 窗口分割成2*1的，当前是第1个子图
plot(t,tz);   % 绘制2PSK信号加入白噪声的波形
axis([0,Tp,-1.5,1.5]);  % 坐标范围设置
title('通过高斯白噪声信道后的信号');% 标题
xlabel('时间/s');           % x轴标签
ylabel('幅度');             % y轴标签
%%
%解调
tz = tz .* carrier;     %相干解调
subplot(2, 1, 2)                % 窗口分割成2*1的，当前是第2个子图
plot(t,tz)    % 绘制乘以相干载波后的信号
axis([0,Tp,-1.5,1.5]);  % 设置坐标范围
title("乘以相干载波后的信号")% 标题
xlabel('时间/s');           % x轴标签
ylabel('幅度');             % y轴标签
%%
%低通滤波器（巴特沃斯滤波器）
fn = fs;    
fp = fm;    %passbound
fb = 2*fm;  %阻带设计为截止频率的两倍
Rp = 3;     %通带最大衰减为3db
Rs = 30;    %阻带最小衰减为30db
Wp = 2*fp / fn;     %归一化
Wb = 2*fb / fn;
[n, Wn] = buttord(Wp, Wb, Rp, Rs);  %n为滤波器最大阶数，Wn为滤波器截止频率
[b, a] = butter(n, Wn);     %b为分子系数，a为分母系数
[H, F] = freqz(b, a, N/2+1, fn);      %对单边带，采样速率为fn的信号滤波

psk_f = fft(tz)/N;     %除N为了归一化（问hy）
psk_fA = 2 * abs(psk_f(1:N/2+1)) .* abs(H)';     %通过滤波器的幅值
figure(3);
subplot(2,1,1);
plot(f(1:N/2+1),psk_fA);
title('通过低通滤波器的幅度谱');  % 标题
xlabel("f/Hz");ylabel("F(jw)");
grid on;
%将左半边搬移到右半边
for i = 1 : N - (N/2+1)
    psk_fA(N/2+1+i) = psk_fA(N/2+1-i);  %左右两边对称
end
psk_f = psk_fA .* exp(1j * angle(psk_f));   %频谱
b = real(ifft(psk_f)*N/2);      %回到时域信号
subplot(2, 1, 2);
plot(t,b,'LineWidth',2);
title("通过低通滤波器的信号");
xlabel("t/ms");ylabel("2PSK");
grid on;
%%
%抽样判决
K = 0;    %判决门限
res = zeros(1, N+50);
for i = 50 : 100 : 950
    if b(1, i) > K
        res(1, i:i+100) = 0;
    else
        res(1, i:i+100) = 1;
    end
end
figure(4);
subplot(2, 1, 1);
plot(t, res(50 : length(res)-1), 'LineWidth', 2);
title("抽样判决后的信号");
xlabel("t/ms");ylabel("res(t)");
grid on;