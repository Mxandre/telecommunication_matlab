clear all;
clc;

%% 基本参数设置
CodeNum = 20;                                       % 码数
OrignalCode = randi([0,15],1,CodeNum);              % 一行CodeNum列的，0或1的基带信号
SampleNum = 100;                                    % 每个码元的采样数
Tb = 0.001;                                         % 码长
fm = 1/Tb;                                          % 基带信号带宽
Tp = CodeNum * Tb;                                  % 观测时间
T = Tb / SampleNum;                                 % 采样间隔
fs = 1/T;                                           % 采样频率
N = CodeNum * SampleNum;                            % 采样点数
t = 0 : T : Tp-T;                                   % 时域采样范围
F = 1/Tp;                                           % 频谱分辨率
fM = F * N;                                         % 频域观测极限
f = 0 : F : fM-F;                                   % 频域观测范围
fc = 10000;                                         % 载波频率
K = 0.8;                                            % 信道传输系数（认为信号只受固定衰减，不失真）
%% 生成基带信号
an = OrignalCode(ones(1,SampleNum), :);             % 对每个码元采样SampleNum次，得到基带信号，但此时是矩阵
an = reshape(an,1,N);                               % 将矩阵变为行向量 得到基带信号


% 完成调制前的正交同相支路数据映射
I=zeros(1,N);Q=zeros(1,N);
A = 1 / sqrt(10);
for i=1:N
    switch an(i)
        case 0, I(i)=3*A; Q(i)=3*A;
        case 1, I(i)=1*A; Q(i)=3*A;
        case 2, I(i)=-3*A; Q(i)=3*A;
        case 3, I(i)=-1*A; Q(i)=3*A;
        case 4, I(i)=3*A;Q(i)=1*A;
        case 5, I(i)=1*A;Q(i)=1*A;
        case 6, I(i)=-3*A;Q(i)=1*A;
        case 7, I(i)=-1*A;Q(i)=1*A;
        case 8, I(i)=3*A; Q(i)=-3*A;
        case 9, I(i)=1*A; Q(i)=-3*A;
        case 10,I(i)=-3*A; Q(i)=-3*A;
        case 11,I(i)=-1*A; Q(i)=-3*A;
        case 12,I(i)=3*A;Q(i)=-1*A;
        case 13,I(i)=1*A;Q(i)=-1*A;
        case 14,I(i)=-3*A;Q(i)=-1*A;
        case 15,I(i)=-1*A;Q(i)=-1*A;
    end
end

CI = cos(2*pi*fc*t);
CQ = sin(2*pi*fc*t);
QAM = I .* CI + Q .* CQ ;
subplot(2,1,1);
plot(t*1000,QAM);
xlabel("t/ms");ylabel("16QAM"); 
title("16QAM调制信号");
%% 传输过程
QAM = K*QAM;                                        % 乘性干扰
QAM = awgn(QAM,20);                                 % 加入高斯白噪声 信噪比为20dB（大信噪比）
subplot(2,1,2);                                     % 绘制接收机输入端的信号时域波形
plot(t*1000,QAM);
xlabel("t/ms");ylabel("16QAM"); 
title("接收机输入端的信号");

% 相干解调
QAM_I = 2*QAM .* CI;
QAM_Q = 2*QAM .* CQ;
%% 低通滤波器
fn = fs;
fp = fm;                                            % 通带
fb = 2*fm;                                          % 阻带
Rp = 3;                                             % 通带最大
Rs = 30;
Wp = 2*fp / fn;                                     % 归一化频率
Wb = 2*fb / fn;
[n,Wn] = buttord(Wp,Wb,Rp,Rs);
[b,a] = butter(n,Wn); 
[H, F] = freqz(b,a,N/2+1, fn);                      % 因为是单边谱，所以除2
figure(2);
subplot(3,2,[1,2]);
plot(F,20*log10(abs(H)));
xlabel("f/Hz");ylabel("幅频特性(dB)"); 
title("低通滤波器的幅频特性");
axis([0,5e3,-40,3]);
%%
QAM_If = fft(QAM_I)/N;
QAM_Qf = fft(QAM_Q)/N;
subplot(3,2,3);
plot(f(1:N/2+1),2*abs(QAM_If(1:N/2+1)));
xlabel("f/Hz");ylabel("QAM\_IfA"); 
title("I支路信号通过低通滤波器前的频谱")
subplot(3,2,4);
plot(f(1:N/2+1),2*abs(QAM_Qf(1:N/2+1)));
xlabel("f/Hz");ylabel("QAM\_QfA"); 
title("Q支路信号通过低通滤波器前的频谱")

QAM_IfA = 2* abs(QAM_If(1:N/2+1)) .* abs(H)';
QAM_QfA = 2* abs(QAM_Qf(1:N/2+1)) .* abs(H)';

subplot(3,2,5);
plot(f(1:N/2+1), QAM_IfA);
xlabel("f/Hz");ylabel("QAM\_IfA"); 
title("I支路信号通过低通滤波器的频谱")
subplot(3,2,6);
plot(f(1:N/2+1), QAM_QfA);
xlabel("f/Hz");ylabel("QAM\_QfA"); 
title("Q支路信号通过低通滤波器的频谱")

for i = 1 : N - (N/2 + 1)
    QAM_IfA(1,N/2+1+i) = QAM_IfA(1,N/2+1-i);
    QAM_QfA(1,N/2+1+i) = QAM_QfA(1,N/2+1-i);
end

QAM_If = QAM_IfA .* exp(1j * angle(QAM_If));
QAM_Qf = QAM_QfA .* exp(1j * angle(QAM_Qf));

QAM_I = real(ifft(QAM_If)*N/2);
QAM_Q = real(ifft(QAM_Qf)*N/2);

figure(4);subplot(2,1,1);plot(t*1e6,QAM_I);
xlabel("t\us");ylabel("QAM_I");
subplot(2,1,2);plot(t*1e6,QAM_Q);
ylabel("QAM_Q")
%抽样判决
k1 = 0;
k2 = 0.67;

start = Tb/2 * 1e5;                                 %开始抽样时刻 码元的中间时刻
res = zeros(1,N + start);

for i = start : 100 : N-start
    if( QAM_I(i) > k2)
        res(1,i:i+99) = res(1,i:i+99) + 0;          %此处判00，可不加 
    elseif( QAM_I(i) >= k1 && QAM_I(i) <= k2)
        res(1,i:i+99) = res(1,i:i+99) + 1;          %此处判01
    elseif( QAM_I(i) >= -k2 && QAM_I(i) < -k1)
        res(1,i:i+99) = res(1,i:i+99) + 3;          %此处判11
    elseif( QAM_I(i) < -k2)
        res(1,i:i+99) = res(1,i:i+99) + 2;          %此处判10
    end

    if( QAM_Q(i) > k2)
        res(1,i:i+99) = res(1,i:i+99) + 0;          %此处判00，可不加 
    elseif( QAM_Q(i) > k1 && QAM_Q(i) <= k2)
        res(1,i:i+99) = res(1,i:i+99) + 4;          %此处判01
    elseif( QAM_Q(i) >= -k2 && QAM_Q(i) < -k1)
        res(1,i:i+99) = res(1,i:i+99) + 12;         %此处判11
    elseif( QAM_Q(i) < -k2)
        res(1,i:i+99) = res(1,i:i+99) + 8;          %此处判10
    end

end

figure(5);                                          %接收序列
plot(t*1000, res(start:end-1));
set(gca,'ytick',0:1:15);
figure(6);                                          %发送序列
plot(t*1000,an);
set(gca,'ytick',0:1:15);