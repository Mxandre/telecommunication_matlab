function [x]= solveLowerTri(A,b)
    y=size(A,1);
    x=zeros(y,1);
    x(1,1)=b(1,1)/A(1,1);
    for i=2:y
        x(i,1)=(b(i)-A(i,1:i-1)*x(1:i-1))/A(i,i);
    end
end
% function x=solveUpperTri(A,b)
%     y=size(A,1);
%     x=zeros(y,1);
%     x(y)=b(y)/A(y,y);
%     for i=y-1:-1:1
%        
%         x(i)=(b(i)-A(i,i+1:y)*x(i+1:y))/A(i,i);
%     end
% end
% function [Achap,bchap,flag]=EliminationGauss(A,b)
%     flag=0;
%     n=size(A,1);
%     for i=1:n
%         if A(i,i)==0
%             flag=1;
%             disp('cannot use in Gauss');
%             break;
%         end
%     end
%     Achap=zeros(n,n);
%     bchap=b;
%     for i=1:n
%         Achap(1,i)=A(1,i);
%     end
%     for i =1:n
%         for j=i+1:n
%             A(j,j:n)=A(j,j:n)-A(j,i)/A(i,i).*A(i,j:n);
%             bchap(j)=bchap(j)-bchap(i)*A(j,i)/A(i,i);
%         end
%     end
% for i=2:n
%     for j=i:n
%         Achap(i,j)=A(i,j);
%     end
% end  
% end
function [L,U]=factorizeLU(A)
    U=A;
    n=size(A);
    L=eye(n);
    for i=2:n
        for j=1:i-1
            L(i,j)=U(i,j)/U(j,j);
            U(i,:)=U(i,:)-L(i,j)*U(j,j);
    end
    end
end



