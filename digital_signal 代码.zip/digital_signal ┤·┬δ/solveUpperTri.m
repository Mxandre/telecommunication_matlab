function x=solveUpperTri(A,b)
    y=size(A,1);
    x=zeros(y,1);
    x(y)=b(y)/A(y,y);
    for i=y-1:-1:1
       
        x(i)=(b(i)-A(i,i+1:y)*x(i+1:y))/A(i,i);
    end
end