clc
clear all
syms t
x=0:10;
f1=heaviside(t)-heaviside(t-2);
plot(x,f1);