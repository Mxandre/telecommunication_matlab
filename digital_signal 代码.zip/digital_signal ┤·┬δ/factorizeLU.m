function [L,U]=factorizeLU(A)
    U=A;
    n=size(A);
    L=eye(n);
    for i=2:n
        for j=1:i-1
            L(i,j)=U(i,j)/U(j,j);
            U(i,:)=U(i,:)-L(i,j)*U(j,:);
    end
    end
end