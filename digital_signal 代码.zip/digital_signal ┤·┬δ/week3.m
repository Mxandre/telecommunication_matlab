N=15;
h=1/N;
x=0:h:1;
A=zeros(N-1,N-1);
A(1,1:2)=[-2,1];
for i=2:N-2
    A(i,i-1:i+1)=[1 -2 1];
end
A(N-1,N-2:N-1)=[1 -2];
A=-A/h^2;
f1=ones(N-1,1);
f2=sin(pi*x(2:N));
[L,U]=factorizeLU(A);
y1=solveLowerTri(L,f1);
u1=solveUpperTri(U,y1);
y2=solveLowerTri(L,f2);
u2=solveUpperTri(U,y2);
xc=linspace(0,1,1000);
subplot(2,1,1);
plot(x',[0;u1;0],'o',xc,-0.5*xc.*(xc-1));
legend('approximation','solution exact');
title(['N=',num2str(N),'approximation et solution exact pour f(x)=1']);
subplot(2,1,2);
plot(x',[0;u2;0],'o',xc,sin(pi*xc)/pi^2);
legend('approximation','solution exact');
title(['N=',num2str(N),'approximation et solution exact pour f(x)=sin(pi*x)']);






