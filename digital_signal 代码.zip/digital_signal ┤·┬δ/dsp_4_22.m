% clc
% clear all
% % dt=0.01;
% % t=0:0.01:2*pi;
% % f1=sin(3*t);
% % f2=cos(2*t+2);
% % y=conv(f1,f2);
% % t2=0:0.01:(length(y)-1)*dt;
% % plot(t2,y);
% dt=0.01;
% t=0:dt:2*pi;
% ft=2*cos(100*pi*t)+cos(60*pi*t);
% wmax=2*pi;
% K=
Dt = 0.00005;
t = -0.005:Dt:0.005;
xa = exp(-1000*abs(t));
% Continuous-time Fourier Transform
Wmax = 2*pi*2000; % angular frequency range
K = 5000;
k = 0:1:K;
W = k*Wmax/K;
Xa = xa * exp(-1j*t'*W) * Dt;
Xa = 2 * abs(Xa);
subplot(2,1,1); 
plot(t*1000,xa);
xlabel('t in msec.'); 
ylabel('xa(t)');
title('Analog Signal');
subplot(2,1,2); 
plot(W/(2*pi*1000),Xa*1000);
xlabel('Frequency in KHz'); ylabel('Xa(jW)*1000');
title('Continuous-time Fourier Transform');
